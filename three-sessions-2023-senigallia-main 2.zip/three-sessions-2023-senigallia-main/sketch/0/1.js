// Rotating cube

import Stats from 'three/addons/libs/stats.module.js' // XXX
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
//import {GLTFLoader} from "three/addons/loaders/GLTLoader.js"

let renderer
let geometry
let material
let animation
let onWindowResize

const scenes = [];

/* tentativo fallimentare di importare il file di cinema con la colonna già modellata
const loader = new GLTFLoader();
loader.load("Colonne.glb");
function ( gltf ) {
    scene.add( gltf.scene );
    gltf.scene; 
    gltf.scenes; 
    gltf.asset;
}

function ( xhr ) { 
    console.log( ( xhr.loaded / xhr.total * 100 ) + '% loaded' ); 
};

function ( error ) { 
    console.log( 'An error happened' ); 
};

*/

export function sketch() {
    console.log("Sketch launched")
    const stats = new Stats() // XXX
    canvas3D.appendChild(stats.dom)

    // RENDERER
    renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: true
    })
    renderer.setSize(window.innerWidth, window.innerHeight)
    canvas3D.appendChild(renderer.domElement)

    // CAMERA
    let camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.z = 20, 0, 0
    // camera = new THREE.PerspectiveCamera( 50, 1, 1, 10 );
	// camera.position.z = 2;

    // WINDOW RESIZE
    const onWindowResize = () => {
        camera.aspect = window.innerWidth / window.innerHeight
        camera.updateProjectionMatrix()
        renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', onWindowResize)

    //SCENE
	const scene = new THREE.Scene();
	scene.userData.camera = camera;
    scene.add( new THREE.Mesh( geometry, material ) );
    scene.add( new THREE.HemisphereLight( 0xaaaaaa, 0x444444 ) );


    // //SOLIDS
	// const geometries = [
    //     new THREE.BoxGeometry( 1, 1, 1 ),
	// 	new THREE.SphereGeometry( 0.5, 12, 8 ),
	// 	new THREE.DodecahedronGeometry( 0.5 ),
	// 	new THREE.CylinderGeometry( 0.5, 0.5, 1, 12 )
	// ];
    //  // add one random mesh to each scene
	// geometry = geometries[ geometries.length * Math.random() | 0 ];
    // material = new THREE.MeshStandardMaterial( {
    //     color: new THREE.Color().setHSL( Math.random(), 1, 0.75, THREE.SRGBColorSpace ),
	// 	roughness: 0.5,
    //     metalness: 0,
    //     flatShading: true

	// } );


    //create a cube and sphere and intersect them
    const cubo = new THREE.Mesh(
        new THREE.BoxGeometry(2, 2, 2),
        new THREE.MeshStandardMaterial({ color: 0x1CFF01 })
    )
    const dodecaedro = new THREE.Mesh(
        new THREE.DodecahedronGeometry(2, 0),
        new THREE.MeshStandardMaterial({ color: 0xFA01E0 })
    )
    const dodecaedro2 = new THREE.Mesh(
        new THREE.DodecahedronGeometry(1, 0),
        new THREE.MeshStandardMaterial({ color: 0x01FFF4 })
    )
    const ottaedro = new THREE.Mesh(
        new THREE.OctahedronGeometry( 2,  ),
        new THREE.MeshStandardMaterial({ color: 0xEAFF00 })
    )
    cubo.position.set(0, 0, 0)
    scene.add(cubo)
    dodecaedro.position.set(0, 2.9, 0)
    scene.add(dodecaedro)
    dodecaedro2.position.set(0, 5.65, 0)
    scene.add(dodecaedro2)
    ottaedro.position.set(0, 8.55, 0)
    scene.add(ottaedro)

    //COLONNA
    const colonna1 = [
        cubo,
        dodecaedro,
        dodecaedro2,
        ottaedro
    ];
    const colonna2 = [
        cubo,
        dodecaedro,
        dodecaedro2,
        ottaedro
    ];
    const colonna3 = [
        cubo,
        dodecaedro,
        dodecaedro2,
        ottaedro
    ];
    const colonna4 = [
        cubo,
        dodecaedro,
        dodecaedro2,
        ottaedro
    ];
    const colonna5 = [
        cubo,
        dodecaedro,
        dodecaedro2,
        ottaedro
    ];

    // CONTROLS
    const controls = new OrbitControls(camera, renderer.domElement,scene.userData.camera, scene.userData.element);
	controls.minDistance = 2;
	controls.maxDistance = 5;
	controls.enablePan = false;
    controls.enableZoom = false;
	scene.userData.controls = controls;

    //LIGHT
    const light = new THREE.DirectionalLight( 0xffffff, 0.5 );
    light.position.set( 1, 1, 1 );
    scene.add( light );

    // ANIMATE
    const animate = () => {
        stats.begin() // XXX

        // ANIMATION


        // ...

        renderer.render(scene, camera) // RENDER
        stats.end() // XXX

        animation = requestAnimationFrame(animate) // CIAK
    }
    animate()
}

function addShadowedLight( x, y, z, color, intensity ) {

				const directionalLight = new THREE.DirectionalLight( color, intensity );
				directionalLight.position.set( x, y, z );
				scene.add( directionalLight );

				directionalLight.castShadow = true;

				const d = 1;
				directionalLight.shadow.camera.left = - d;
				directionalLight.shadow.camera.right = d;
				directionalLight.shadow.camera.top = d;
				directionalLight.shadow.camera.bottom = - d;

				directionalLight.shadow.camera.near = 1;
				directionalLight.shadow.camera.far = 4;

				directionalLight.shadow.bias = - 0.002;

			}

export function dispose() {
    cancelAnimationFrame(animation)
    renderer.dispose()
    geometry.dispose()
    material.dispose()
    window.removeEventListener('resize', onWindowResize)
}


