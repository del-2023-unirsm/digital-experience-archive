let x = 0;
let y = 0;
let g = 30; //grid size
var colore = 200; // current grid color

function setup() {
  createCanvas(800, 700);
  background(37,170,29);
  stroke(0);
}

function draw() {
   preparaQuadretto();
  // riga proporzionale alla griglia
  strokeWeight(g / 10);
  if (random(2) < 1.9) {
    //mattoncino
    fill(198, 108, 0); 
    rect(x, y, g, g);
  } else {
    //? block
    fill(255, 255, 5);
    rect(x, y, g, g);
    fill(198, 108, 0);
    strokeWeight(1.5)
    stroke(198, 108, 0);
    textFont('Courier New');
    textSize(g * 0.6);
    textAlign(CENTER, CENTER);
    text("?", x + g / 2, y + g / 2);
  }

  // passo alla casella a lato
  x += g;

  // se sono in fondo alla riga vado a capo alla riga successiva
  if (x > width) {
    x = 0;
    y += g;
    preparaRiga();
  }
  
  // se sono in fondo alla pagina ricomincio con colore e griglia differente
  if (y > height) {
    y = 0;
    colore = random(255);
    g = 5 + random(width);
    preparaRiga();
  }
}

// riparti se premi il mouse e cambia il colore 
function mousePressed() {
  colore = [random(256), random(256), random(256)];
  background(0);
  redraw();
}

// cancella una riga prima di disegnarci
function preparaRiga() {
  /*fill(colore);
  noStroke();
  rect(0,height-g*y-g-1,width,g+1);
  stroke(255-colore);*/
}

// cancella un quadretto prima di disegnarci
function preparaQuadretto() {
  fill(colore);
  noStroke();
  rect(x, y, g, g);
  //rect(x*g,height-g*(y+1),g-(g/20),g-(g/20));
  stroke(0);
}

// se ridimensiona la finestra ricalcola width e height canvas
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}